/* Halverson Speedway Marketing Tool - Template Editor */

class TemplateEditor {
    constructor() {
        this.canvas = null;
        this.selectedObject = null;
        this.canvasContainer = document.querySelector('.canvas-container');
        this.templateData = null;
        this.templateId = null;
        this.history = [];
        this.historyIndex = -1;
        this.maxHistorySteps = 20;
        this.initialized = false;
        this.canvasScale = 1;
        this.aspectRatio = 1;
    }

    initialize() {
        // Get template ID from URL
        const urlParams = new URLSearchParams(window.location.search);
        this.templateId = urlParams.get('template');
        
        if (!this.templateId) {
            alert('No template specified');
            return;
        }
        
        // Load template data
        this.loadTemplateData()
            .then(() => {
                this.initializeCanvas();
                this.setupEventListeners();
                this.initialized = true;
                window.templateEditor = this; // Make available globally
            })
            .catch(error => {
                console.error('Error initializing editor:', error);
                alert('Failed to initialize editor');
            });
    }
    
    async loadTemplateData() {
        try {
            const response = await fetch('/assets/templates/template-data.json');
            const data = await response.json();
            
            // Find the template by ID
            let template = null;
            
            // Search through all categories
            for (const category of data.categories) {
                const found = category.templates.find(t => t.id === this.templateId);
                if (found) {
                    template = found;
                    break;
                }
            }
            
            if (!template) {
                throw new Error('Template not found');
            }
            
            this.templateData = template;
            
            // Update page title and description
            document.getElementById('editor-title').textContent = `Editing: ${template.name}`;
            document.getElementById('editor-description').textContent = template.description;
            
            return template;
        } catch (error) {
            console.error('Error loading template data:', error);
            throw error;
        }
    }
    
    initializeCanvas() {
        const templateWidth = this.templateData.width || 800;
        const templateHeight = this.templateData.height || 600;
        
        // Calculate aspect ratio
        this.aspectRatio = templateHeight / templateWidth;
        
        // Create fabric.js canvas with original dimensions
        this.canvas = new fabric.Canvas('editor-canvas', {
            backgroundColor: '#000000', // Default black background
            width: templateWidth,
            height: templateHeight,
            preserveObjectStacking: true,
            selection: true // Allow selection of multiple objects
        });
        
        // Update canvas dimensions display
        document.getElementById('canvas-dimensions').textContent = 
            `${templateWidth} × ${templateHeight}px`;
        
        // Load template elements
        this.loadTemplateElements();
        
        // Apply proper scaling to maintain aspect ratio
        this.handleResize();
        
        // Save initial state
        this.saveState();
    }
    
    applyCanvasScaling() {
        const templateWidth = this.templateData.width || 800;
        const templateHeight = this.templateData.height || 600;
        
        // Get the canvas wrapper and container
        const canvasWrapper = document.querySelector('.canvas-wrapper');
        
        if (canvasWrapper) {
            // Set the wrapper to be a flex container for centering
            canvasWrapper.style.display = 'flex';
            canvasWrapper.style.justifyContent = 'center';
            canvasWrapper.style.alignItems = 'center';
            canvasWrapper.style.width = '100%';
            canvasWrapper.style.minHeight = '300px'; // Minimum height to ensure visibility
            canvasWrapper.style.height = 'auto';
            canvasWrapper.style.overflow = 'hidden';
            
            // Calculate the scaled dimensions
            const scaledWidth = Math.floor(templateWidth * this.canvasScale);
            const scaledHeight = Math.floor(templateHeight * this.canvasScale);
            
            // Set the canvas container to maintain aspect ratio
            this.canvasContainer.style.position = 'relative';
            this.canvasContainer.style.width = `${scaledWidth}px`;
            this.canvasContainer.style.height = `${scaledHeight}px`;
            this.canvasContainer.style.margin = 'auto'; // Center horizontally
            
            // Ensure the canvas element itself is properly sized
            const canvasElement = document.getElementById('editor-canvas');
            if (canvasElement) {
                canvasElement.style.width = '100%';
                canvasElement.style.height = '100%';
                canvasElement.style.display = 'block';
            }
            
            // Update the canvas size for fabric.js
            this.canvas.setDimensions({
                width: scaledWidth,
                height: scaledHeight
            }, { cssOnly: true });
            
            // Set the zoom level to match the scale
            this.canvas.setZoom(this.canvasScale);
            
            // Ensure the canvas container is visible
            this.canvasContainer.style.visibility = 'visible';
            this.canvasContainer.style.opacity = '1';
            this.canvasContainer.style.display = 'block';
        }
    }
    
    loadTemplateElements() {
        if (!this.templateData.elements) {
            return;
        }
        
        // Process each element
        this.templateData.elements.forEach(element => {
            switch (element.type) {
                case 'text':
                    this.addTextElement(element);
                    break;
                case 'image':
                    this.addImageElement(element);
                    break;
                case 'shape':
                    this.addShapeElement(element);
                    break;
                case 'background':
                    this.setBackground(element);
                    break;
                default:
                    console.warn('Unknown element type:', element.type);
            }
        });
        
        // Render canvas
        this.canvas.renderAll();
    }
    
    addTextElement(element) {
        // Determine text alignment and adjust origin accordingly
        let originX = 'left';
        if (element.textAlign === 'center') {
            originX = 'center';
        } else if (element.textAlign === 'right') {
            originX = 'right';
        }
        
        // Create text options
        const textOptions = {
            left: element.left,
            top: element.top,
            fontFamily: element.fontFamily || 'Racing Sans One',
            fontSize: element.fontSize || 36,
            fill: element.color || '#000000',
            fontWeight: element.bold ? 'bold' : 'normal',
            fontStyle: element.italic ? 'italic' : 'normal',
            underline: element.underline || false,
            textAlign: element.textAlign || 'left',
            originX: originX,
            originY: 'center',
            id: element.id || 'text_' + Math.random().toString(36).substr(2, 9)
        };
        
        // Create text object
        const text = new fabric.Text(element.text || 'Edit this text', textOptions);
        
        // Add custom properties
        text.toObject = (function(toObject) {
            return function() {
                return fabric.util.object.extend(toObject.call(this), {
                    id: this.id
                });
            };
        })(text.toObject);
        
        this.canvas.add(text);
        return text;
    }
    
    addImageElement(element) {
        fabric.Image.fromURL(element.src || '/assets/images/placeholder.jpg', img => {
            img.set({
                left: element.left,
                top: element.top,
                originX: 'left',
                originY: 'top',
                scaleX: element.scaleX || 1,
                scaleY: element.scaleY || 1,
                angle: element.angle || 0,
                opacity: element.opacity || 1,
                id: element.id || 'image_' + Math.random().toString(36).substr(2, 9)
            });
            
            // Add custom properties
            img.toObject = (function(toObject) {
                return function() {
                    return fabric.util.object.extend(toObject.call(this), {
                        id: this.id
                    });
                };
            })(img.toObject);
            
            this.canvas.add(img);
            this.canvas.renderAll();
        });
    }
    
    addShapeElement(element) {
        let shape;
        
        // Common options for all shapes
        const shapeOptions = {
            left: element.left,
            top: element.top,
            originX: 'left',
            originY: 'top',
            fill: element.fill || '#D12026',
            stroke: element.stroke || '',
            strokeWidth: element.strokeWidth || 0,
            angle: element.angle || 0,
            opacity: element.opacity || 1,
            id: element.id || 'shape_' + Math.random().toString(36).substr(2, 9)
        };
        
        switch (element.shape) {
            case 'rect':
                shape = new fabric.Rect({
                    ...shapeOptions,
                    width: element.width || 100,
                    height: element.height || 100,
                    rx: element.rx || 0,
                    ry: element.ry || 0
                });
                break;
                
            case 'circle':
                shape = new fabric.Circle({
                    ...shapeOptions,
                    radius: element.radius || 50
                });
                break;
                
            case 'triangle':
                shape = new fabric.Triangle({
                    ...shapeOptions,
                    width: element.width || 100,
                    height: element.height || 100
                });
                break;
                
            case 'line':
                shape = new fabric.Line([
                    element.x1 || 0, 
                    element.y1 || 0, 
                    element.x2 || 100, 
                    element.y2 || 100
                ], {
                    ...shapeOptions,
                    stroke: element.stroke || '#D12026',
                    strokeWidth: element.strokeWidth || 2
                });
                break;
                
            default:
                console.warn('Unknown shape type:', element.shape);
                return;
        }
        
        // Add custom properties
        shape.toObject = (function(toObject) {
            return function() {
                return fabric.util.object.extend(toObject.call(this), {
                    id: this.id
                });
            };
        })(shape.toObject);
        
        this.canvas.add(shape);
        return shape;
    }
    
    setBackground(element) {
        if (element.color) {
            this.canvas.setBackgroundColor(element.color, this.canvas.renderAll.bind(this.canvas));
        } else if (element.src) {
            fabric.Image.fromURL(element.src, img => {
                // Ensure the background image fills the entire canvas
                const canvasWidth = this.canvas.width;
                const canvasHeight = this.canvas.height;
                
                // Calculate scale to fill the entire canvas
                const scaleX = canvasWidth / img.width;
                const scaleY = canvasHeight / img.height;
                
                // Use the larger scale to ensure the image fills the canvas
                const scale = Math.max(scaleX, scaleY);
                
                this.canvas.setBackgroundImage(img, this.canvas.renderAll.bind(this.canvas), {
                    scaleX: scale,
                    scaleY: scale,
                    // Center the image if it's larger than the canvas
                    left: (canvasWidth - img.width * scale) / 2,
                    top: (canvasHeight - img.height * scale) / 2
                });
            });
        }
    }
    
    setupEventListeners() {
        // Canvas selection events
        this.canvas.on('selection:created', this.handleSelectionChange.bind(this));
        this.canvas.on('selection:updated', this.handleSelectionChange.bind(this));
        this.canvas.on('selection:cleared', this.handleSelectionCleared.bind(this));
        
        // Canvas modification events
        this.canvas.on('object:modified', this.handleObjectModified.bind(this));
        
        // Text controls
        document.getElementById('font-family')?.addEventListener('change', this.handleFontFamilyChange.bind(this));
        document.getElementById('font-size')?.addEventListener('input', this.handleFontSizeChange.bind(this));
        document.getElementById('bold-button')?.addEventListener('click', this.handleBoldClick.bind(this));
        document.getElementById('italic-button')?.addEventListener('click', this.handleItalicClick.bind(this));
        document.getElementById('underline-button')?.addEventListener('click', this.handleUnderlineClick.bind(this));
        
        // Color buttons
        const colorButtons = document.querySelectorAll('[data-color]');
        colorButtons.forEach(button => {
            button.addEventListener('click', () => {
                const color = button.getAttribute('data-color');
                this.setTextColor(color);
            });
            
            // Set button background color
            button.style.backgroundColor = button.getAttribute('data-color');
        });
        
        // Custom color picker
        document.getElementById('custom-color')?.addEventListener('input', (e) => {
            this.setTextColor(e.target.value);
        });
        
        // Action buttons
        document.getElementById('reset-button')?.addEventListener('click', this.resetTemplate.bind(this));
        document.getElementById('preview-button')?.addEventListener('click', this.previewTemplate.bind(this));
        
        // Export buttons
        document.getElementById('download-image-button')?.addEventListener('click', this.downloadAsImage.bind(this));
        document.getElementById('download-pdf-button')?.addEventListener('click', this.downloadAsPDF.bind(this));
        document.getElementById('copy-image-button')?.addEventListener('click', this.copyToClipboard.bind(this));
        document.getElementById('save-template-button')?.addEventListener('click', this.saveTemplate.bind(this));
        
        // Handle window resize
        window.addEventListener('resize', this.handleResize.bind(this));
        
        // Handle orientation change specifically for mobile
        window.addEventListener('orientationchange', () => {
            // Wait for orientation change to complete
            setTimeout(this.handleResize.bind(this), 300);
        });
    }
    
    handleResize() {
        // Get container dimensions
        const containerWidth = this.canvasContainer.parentElement.clientWidth - 40; // 20px padding on each side
        const containerHeight = Math.max(300, window.innerHeight * 0.6); // Use at least 300px or 60% of viewport height
        
        // Get template dimensions
        const templateWidth = this.templateData.width || 800;
        const templateHeight = this.templateData.height || 600;
        
        // Calculate scale to fit canvas in container while preserving aspect ratio
        const scaleByWidth = containerWidth / templateWidth;
        const scaleByHeight = containerHeight / templateHeight;
        
        // Use the smaller scale to ensure the entire canvas fits
        this.canvasScale = Math.min(scaleByWidth, scaleByHeight);
        
        // Apply proper scaling to maintain aspect ratio and center the canvas
        this.applyCanvasScaling();
        
        // Re-render canvas
        this.canvas.renderAll();
        
        // Force visibility after resize
        this.forceCanvasVisibility();
    }
    
    forceCanvasVisibility() {
        // Force canvas to be visible
        const canvas = document.getElementById('editor-canvas');
        if (canvas) {
            canvas.style.visibility = 'visible';
            canvas.style.opacity = '1';
            canvas.style.display = 'block';
        }
        
        // Force canvas container to be visible
        if (this.canvasContainer) {
            this.canvasContainer.style.visibility = 'visible';
            this.canvasContainer.style.opacity = '1';
            this.canvasContainer.style.display = 'block';
        }
        
        // Force aspect ratio container to be visible if it exists
        const aspectRatioContainer = document.querySelector('.aspect-ratio-container');
        if (aspectRatioContainer) {
            aspectRatioContainer.style.visibility = 'visible';
            aspectRatioContainer.style.opacity = '1';
            aspectRatioContainer.style.display = 'flex';
        }
    }
    
    handleSelectionChange(e) {
        const selectedObject = e.selected[0];
        this.selectedObject = selectedObject;
        
        if (selectedObject.type === 'text' || selectedObject.type === 'i-text' || selectedObject.type === 'textbox') {
            this.showTextControls(selectedObject);
        } else {
            this.hideTextControls();
        }
    }
    
    handleSelectionCleared() {
        this.selectedObject = null;
        this.hideTextControls();
    }
    
    handleObjectModified() {
        this.saveState();
    }
    
    showTextControls(textObject) {
        // Show text controls
        document.getElementById('text-controls').classList.remove('hidden');
        
        // Update text content
        const textContent = document.getElementById('text-content');
        if (textContent) {
            textContent.value = textObject.text;
            textContent.addEventListener('input', (e) => {
                textObject.set('text', e.target.value);
                this.canvas.renderAll();
            });
        }
        
        // Update font family
        const fontFamily = document.getElementById('font-family');
        if (fontFamily) {
            fontFamily.value = textObject.fontFamily;
        }
        
        // Update font size
        const fontSize = document.getElementById('font-size');
        if (fontSize) {
            fontSize.value = textObject.fontSize;
        }
        
        // Update style buttons
        const boldButton = document.getElementById('bold-button');
        if (boldButton) {
            boldButton.classList.toggle('bg-gray-400', textObject.fontWeight === 'bold');
        }
        
        const italicButton = document.getElementById('italic-button');
        if (italicButton) {
            italicButton.classList.toggle('bg-gray-400', textObject.fontStyle === 'italic');
        }
        
        const underlineButton = document.getElementById('underline-button');
        if (underlineButton) {
            underlineButton.classList.toggle('bg-gray-400', textObject.underline);
        }
        
        // Update color picker
        const customColor = document.getElementById('custom-color');
        if (customColor) {
            customColor.value = textObject.fill;
        }
    }
    
    hideTextControls() {
        document.getElementById('text-controls').classList.add('hidden');
    }
    
    handleFontFamilyChange(e) {
        if (!this.selectedObject) return;
        
        this.selectedObject.set('fontFamily', e.target.value);
        this.canvas.renderAll();
        this.saveState();
    }
    
    handleFontSizeChange(e) {
        if (!this.selectedObject) return;
        
        this.selectedObject.set('fontSize', parseInt(e.target.value, 10));
        this.canvas.renderAll();
        this.saveState();
    }
    
    handleBoldClick() {
        if (!this.selectedObject) return;
        
        const isBold = this.selectedObject.fontWeight === 'bold';
        this.selectedObject.set('fontWeight', isBold ? 'normal' : 'bold');
        
        // Toggle button state
        document.getElementById('bold-button').classList.toggle('bg-gray-400');
        
        this.canvas.renderAll();
        this.saveState();
    }
    
    handleItalicClick() {
        if (!this.selectedObject) return;
        
        const isItalic = this.selectedObject.fontStyle === 'italic';
        this.selectedObject.set('fontStyle', isItalic ? 'normal' : 'italic');
        
        // Toggle button state
        document.getElementById('italic-button').classList.toggle('bg-gray-400');
        
        this.canvas.renderAll();
        this.saveState();
    }
    
    handleUnderlineClick() {
        if (!this.selectedObject) return;
        
        const isUnderlined = this.selectedObject.underline;
        this.selectedObject.set('underline', !isUnderlined);
        
        // Toggle button state
        document.getElementById('underline-button').classList.toggle('bg-gray-400');
        
        this.canvas.renderAll();
        this.saveState();
    }
    
    setTextColor(color) {
        if (!this.selectedObject) return;
        
        this.selectedObject.set('fill', color);
        this.canvas.renderAll();
        this.saveState();
    }
    
    resetTemplate() {
        if (confirm('Reset template to original state?')) {
            // Reload the page to reset everything
            window.location.reload();
        }
    }
    
    previewTemplate() {
        // Toggle preview mode
        const editorContainer = document.getElementById('editor-container');
        editorContainer.classList.toggle('preview-mode');
        
        // Update button text
        const previewButton = document.getElementById('preview-button');
        if (previewButton) {
            previewButton.textContent = editorContainer.classList.contains('preview-mode') 
                ? 'Exit Preview' 
                : 'Preview';
        }
    }
    
    downloadAsImage() {
        // Temporarily disable selection borders
        const objects = this.canvas.getObjects();
        objects.forEach(obj => {
            obj.set({
                hasControls: false,
                hasBorders: false,
                selectable: false
            });
        });
        
        this.canvas.discardActiveObject().renderAll();
        
        // Get data URL
        const dataURL = this.canvas.toDataURL({
            format: 'png',
            quality: 1,
            multiplier: 2 // Higher resolution
        });
        
        // Create download link
        const link = document.createElement('a');
        link.download = `${this.templateData.name.replace(/\s+/g, '-').toLowerCase()}.png`;
        link.href = dataURL;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Restore selection borders
        objects.forEach(obj => {
            obj.set({
                hasControls: true,
                hasBorders: true,
                selectable: true
            });
        });
        
        this.canvas.renderAll();
    }
    
    downloadAsPDF() {
        // Temporarily disable selection borders
        const objects = this.canvas.getObjects();
        objects.forEach(obj => {
            obj.set({
                hasControls: false,
                hasBorders: false,
                selectable: false
            });
        });
        
        this.canvas.discardActiveObject().renderAll();
        
        // Get data URL
        const dataURL = this.canvas.toDataURL({
            format: 'png',
            quality: 1,
            multiplier: 2 // Higher resolution
        });
        
        // Create PDF
        const pdf = new jspdf.jsPDF({
            orientation: this.canvas.width > this.canvas.height ? 'landscape' : 'portrait',
            unit: 'px',
            format: [this.canvas.width, this.canvas.height]
        });
        
        pdf.addImage(dataURL, 'PNG', 0, 0, this.canvas.width, this.canvas.height);
        pdf.save(`${this.templateData.name.replace(/\s+/g, '-').toLowerCase()}.pdf`);
        
        // Restore selection borders
        objects.forEach(obj => {
            obj.set({
                hasControls: true,
                hasBorders: true,
                selectable: true
            });
        });
        
        this.canvas.renderAll();
    }
    
    copyToClipboard() {
        // Temporarily disable selection borders
        const objects = this.canvas.getObjects();
        objects.forEach(obj => {
            obj.set({
                hasControls: false,
                hasBorders: false,
                selectable: false
            });
        });
        
        this.canvas.discardActiveObject().renderAll();
        
        // Get data URL
        const dataURL = this.canvas.toDataURL({
            format: 'png',
            quality: 1,
            multiplier: 2 // Higher resolution
        });
        
        // Create an image element
        const img = new Image();
        img.src = dataURL;
        
        // When the image is loaded, copy it to clipboard
        img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = img.width;
            canvas.height = img.height;
            
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0);
            
            canvas.toBlob(blob => {
                try {
                    navigator.clipboard.write([
                        new ClipboardItem({
                            'image/png': blob
                        })
                    ]).then(() => {
                        alert('Image copied to clipboard!');
                    }).catch(err => {
                        console.error('Error copying to clipboard:', err);
                        alert('Failed to copy to clipboard. Your browser may not support this feature.');
                    });
                } catch (err) {
                    console.error('Error copying to clipboard:', err);
                    alert('Failed to copy to clipboard. Your browser may not support this feature.');
                }
            });
        };
        
        // Restore selection borders
        objects.forEach(obj => {
            obj.set({
                hasControls: true,
                hasBorders: true,
                selectable: true
            });
        });
        
        this.canvas.renderAll();
    }
    
    saveTemplate() {
        alert('Template saved successfully!');
    }
    
    saveState() {
        // Get current canvas state
        const json = JSON.stringify(this.canvas.toJSON(['id']));
        
        // If we're not at the end of the history, truncate
        if (this.historyIndex < this.history.length - 1) {
            this.history = this.history.slice(0, this.historyIndex + 1);
        }
        
        // Add new state to history
        this.history.push(json);
        
        // Limit history size
        if (this.history.length > this.maxHistorySteps) {
            this.history.shift();
        }
        
        // Update index
        this.historyIndex = this.history.length - 1;
    }
    
    undo() {
        if (this.historyIndex > 0) {
            this.historyIndex--;
            this.loadState(this.history[this.historyIndex]);
        }
    }
    
    redo() {
        if (this.historyIndex < this.history.length - 1) {
            this.historyIndex++;
            this.loadState(this.history[this.historyIndex]);
        }
    }
    
    loadState(json) {
        this.canvas.loadFromJSON(json, () => {
            this.canvas.renderAll();
        });
    }
    
    reinitializeCanvas() {
        // Save current state
        const json = this.canvas.toJSON(['id']);
        
        // Get the canvas element
        const canvasElement = document.getElementById('editor-canvas');
        
        // Create a new canvas instance
        this.canvas = new fabric.Canvas('editor-canvas', {
            backgroundColor: '#000000',
            width: this.templateData.width || 800,
            height: this.templateData.height || 600,
            preserveObjectStacking: true,
            selection: true
        });
        
        // Restore state
        this.canvas.loadFromJSON(json, () => {
            // Reattach event listeners
            this.canvas.on('selection:created', this.handleSelectionChange.bind(this));
            this.canvas.on('selection:updated', this.handleSelectionChange.bind(this));
            this.canvas.on('selection:cleared', this.handleSelectionCleared.bind(this));
            this.canvas.on('object:modified', this.handleObjectModified.bind(this));
            
            // Apply scaling
            this.handleResize();
            
            // Render canvas
            this.canvas.renderAll();
        });
    }
}

// Initialize editor when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const editor = new TemplateEditor();
    editor.initialize();
});
