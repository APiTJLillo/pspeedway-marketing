/* Halverson Speedway Marketing Tool - Template Editor */

class TemplateEditor {
    constructor() {
        this.canvas = null;
        this.selectedObject = null;
        this.canvasContainer = document.querySelector('.canvas-container');
        this.templateData = null;
        this.templateId = null;
        this.history = [];
        this.historyIndex = -1;
        this.maxHistorySteps = 20;
        this.initialized = false;
        this.canvasScale = 1;
        this.aspectRatio = 1;
    }

    initialize() {
        // Get template ID from URL
        const urlParams = new URLSearchParams(window.location.search);
        this.templateId = urlParams.get('template');
        
        if (!this.templateId) {
            alert('No template specified');
            return;
        }
        
        // Load template data
        this.loadTemplateData()
            .then(() => {
                this.initializeCanvas();
                this.setupEventListeners();
                this.initialized = true;
                window.templateEditor = this; // Make available globally
            })
            .catch(error => {
                console.error('Error initializing editor:', error);
                alert('Failed to initialize editor');
            });
    }
    
    async loadTemplateData() {
        try {
            const response = await fetch('/assets/templates/template-data.json');
            const data = await response.json();
            
            // Find the template by ID
            let template = null;
            
            // Search through all categories
            for (const category of data.categories) {
                const found = category.templates.find(t => t.id === this.templateId);
                if (found) {
                    template = found;
                    break;
                }
            }
            
            if (!template) {
                throw new Error('Template not found');
            }
            
            this.templateData = template;
            
            // Update page title and description
            document.getElementById('editor-title').textContent = `Editing: ${template.name}`;
            document.getElementById('editor-description').textContent = template.description;
            
            return template;
        } catch (error) {
            console.error('Error loading template data:', error);
            throw error;
        }
    }
    
    initializeCanvas() {
        const templateWidth = this.templateData.width || 800;
        const templateHeight = this.templateData.height || 600;
        
        // Calculate aspect ratio
        this.aspectRatio = templateHeight / templateWidth;
        
        // Create fabric.js canvas with original dimensions
        this.canvas = new fabric.Canvas('editor-canvas', {
            backgroundColor: '#000000', // Default black background
            width: templateWidth,
            height: templateHeight,
            preserveObjectStacking: true,
            selection: true // Allow selection of multiple objects
        });
        
        // Update canvas dimensions display
        document.getElementById('canvas-dimensions').textContent = 
            `${templateWidth} × ${templateHeight}px`;
        
        // Load template elements
        this.loadTemplateElements();
        
        // Apply proper scaling to maintain aspect ratio
        this.handleResize();
        
        // Save initial state
        this.saveState();
    }
    
    applyCanvasScaling() {
        const templateWidth = this.templateData.width || 800;
        const templateHeight = this.templateData.height || 600;
        
        // Get the canvas wrapper and container
        const canvasWrapper = document.querySelector('.canvas-wrapper');
        
        if (canvasWrapper) {
            // Set the wrapper to be a flex container for centering
            canvasWrapper.style.display = 'flex';
            canvasWrapper.style.justifyContent = 'center';
            canvasWrapper.style.alignItems = 'center';
            canvasWrapper.style.width = '100%';
            canvasWrapper.style.minHeight = '300px'; // Minimum height to ensure visibility
            canvasWrapper.style.height = 'auto';
            canvasWrapper.style.overflow = 'hidden';
            
            // Calculate the scaled dimensions
            const scaledWidth = Math.floor(templateWidth * this.canvasScale);
            const scaledHeight = Math.floor(templateHeight * this.canvasScale);
            
            // Set the canvas container to maintain aspect ratio
            this.canvasContainer.style.position = 'relative';
            this.canvasContainer.style.width = `${scaledWidth}px`;
            this.canvasContainer.style.height = `${scaledHeight}px`;
            this.canvasContainer.style.margin = 'auto'; // Center horizontally
            
            // Ensure the canvas element itself is properly sized
            const canvasElement = document.getElementById('editor-canvas');
            if (canvasElement) {
                canvasElement.style.width = '100%';
                canvasElement.style.height = '100%';
                canvasElement.style.display = 'block';
            }
            
            // Update the canvas size for fabric.js
            this.canvas.setDimensions({
                width: scaledWidth,
                height: scaledHeight
            }, { cssOnly: true });
            
            // Set the zoom level to match the scale
            this.canvas.setZoom(this.canvasScale);
        }
    }
    
    loadTemplateElements() {
        if (!this.templateData.elements) {
            return;
        }
        
        // Process each element
        this.templateData.elements.forEach(element => {
            switch (element.type) {
                case 'text':
                    this.addTextElement(element);
                    break;
                case 'image':
                    this.addImageElement(element);
                    break;
                case 'shape':
                    this.addShapeElement(element);
                    break;
                case 'background':
                    this.setBackground(element);
                    break;
                default:
                    console.warn('Unknown element type:', element.type);
            }
        });
        
        // Render canvas
        this.canvas.renderAll();
    }
    
    addTextElement(element) {
        // Determine text alignment and adjust origin accordingly
        let originX = 'left';
        if (element.textAlign === 'center') {
            originX = 'center';
        } else if (element.textAlign === 'right') {
            originX = 'right';
        }
        
        // Create text options
        const textOptions = {
            left: element.left,
            top: element.top,
            fontFamily: element.fontFamily || 'Racing Sans One',
            fontSize: element.fontSize || 36,
            fill: element.color || '#000000',
            fontWeight: element.bold ? 'bold' : 'normal',
            fontStyle: element.italic ? 'italic' : 'normal',
            underline: element.underline || false,
            textAlign: element.textAlign || 'left',
            originX: originX,
            originY: 'center',
            id: element.id || 'text_' + Math.random().toString(36).substr(2, 9)
        };
        
        // Create text object
        const text = new fabric.Text(element.text || 'Edit this text', textOptions);
        
        // Add custom properties
        text.toObject = (function(toObject) {
            return function() {
                return fabric.util.object.extend(toObject.call(this), {
                    id: this.id
                });
            };
        })(text.toObject);
        
        this.canvas.add(text);
        return text;
    }
    
    addImageElement(element) {
        fabric.Image.fromURL(element.src || '/assets/images/placeholder.jpg', img => {
            img.set({
                left: element.left,
                top: element.top,
                originX: 'left',
                originY: 'top',
                scaleX: element.scaleX || 1,
                scaleY: element.scaleY || 1,
                angle: element.angle || 0,
                opacity: element.opacity || 1,
                id: element.id || 'image_' + Math.random().toString(36).substr(2, 9)
            });
            
            // Add custom properties
            img.toObject = (function(toObject) {
                return function() {
                    return fabric.util.object.extend(toObject.call(this), {
                        id: this.id
                    });
                };
            })(img.toObject);
            
            this.canvas.add(img);
            this.canvas.renderAll();
        });
    }
    
    addShapeElement(element) {
        let shape;
        
        // Common options for all shapes
        const shapeOptions = {
            left: element.left,
            top: element.top,
            originX: 'left',
            originY: 'top',
            fill: element.fill || '#D12026',
            stroke: element.stroke || '',
            strokeWidth: element.strokeWidth || 0,
            angle: element.angle || 0,
            opacity: element.opacity || 1,
            id: element.id || 'shape_' + Math.random().toString(36).substr(2, 9)
        };
        
        switch (element.shape) {
            case 'rect':
                shape = new fabric.Rect({
                    ...shapeOptions,
                    width: element.width || 100,
                    height: element.height || 100,
                    rx: element.rx || 0,
                    ry: element.ry || 0
                });
                break;
                
            case 'circle':
                shape = new fabric.Circle({
                    ...shapeOptions,
                    radius: element.radius || 50
                });
                break;
                
            case 'triangle':
                shape = new fabric.Triangle({
                    ...shapeOptions,
                    width: element.width || 100,
                    height: element.height || 100
                });
                break;
                
            case 'line':
                shape = new fabric.Line([
                    element.x1 || 0, 
                    element.y1 || 0, 
                    element.x2 || 100, 
                    element.y2 || 100
                ], {
                    ...shapeOptions,
                    stroke: element.stroke || '#D12026',
                    strokeWidth: element.strokeWidth || 2
                });
                break;
                
            default:
                console.warn('Unknown shape type:', element.shape);
                return;
        }
        
        // Add custom properties
        shape.toObject = (function(toObject) {
            return function() {
                return fabric.util.object.extend(toObject.call(this), {
                    id: this.id
                });
            };
        })(shape.toObject);
        
        this.canvas.add(shape);
        return shape;
    }
    
    setBackground(element) {
        if (element.color) {
            this.canvas.setBackgroundColor(element.color, this.canvas.renderAll.bind(this.canvas));
        } else if (element.src) {
            fabric.Image.fromURL(element.src, img => {
                this.canvas.setBackgroundImage(img, this.canvas.renderAll.bind(this.canvas), {
                    scaleX: this.canvas.width / img.width,
                    scaleY: this.canvas.height / img.height
                });
            });
        }
    }
    
    setupEventListeners() {
        // Canvas selection events
        this.canvas.on('selection:created', this.handleSelectionChange.bind(this));
        this.canvas.on('selection:updated', this.handleSelectionChange.bind(this));
        this.canvas.on('selection:cleared', this.handleSelectionCleared.bind(this));
        
        // Canvas modification events
        this.canvas.on('object:modified', this.handleObjectModified.bind(this));
        
        // Text controls
        document.getElementById('font-family')?.addEventListener('change', this.handleFontFamilyChange.bind(this));
        document.getElementById('font-size')?.addEventListener('input', this.handleFontSizeChange.bind(this));
        document.getElementById('bold-button')?.addEventListener('click', this.handleBoldClick.bind(this));
        document.getElementById('italic-button')?.addEventListener('click', this.handleItalicClick.bind(this));
        document.getElementById('underline-button')?.addEventListener('click', this.handleUnderlineClick.bind(this));
        
        // Color buttons
        const colorButtons = document.querySelectorAll('[data-color]');
        colorButtons.forEach(button => {
            button.addEventListener('click', () => {
                const color = button.getAttribute('data-color');
                this.setTextColor(color);
            });
            
            // Set button background color
            button.style.backgroundColor = button.getAttribute('data-color');
        });
        
        // Custom color picker
        document.getElementById('custom-color')?.addEventListener('input', (e) => {
            this.setTextColor(e.target.value);
        });
        
        // Action buttons
        document.getElementById('reset-button')?.addEventListener('click', this.resetTemplate.bind(this));
        document.getElementById('preview-button')?.addEventListener('click', this.previewTemplate.bind(this));
        
        // Export buttons
        document.getElementById('download-image-button')?.addEventListener('click', this.downloadAsImage.bind(this));
        document.getElementById('download-pdf-button')?.addEventListener('click', this.downloadAsPDF.bind(this));
        document.getElementById('copy-image-button')?.addEventListener('click', this.copyToClipboard.bind(this));
        document.getElementById('save-template-button')?.addEventListener('click', this.saveTemplate.bind(this));
        
        // Handle window resize
        window.addEventListener('resize', this.handleResize.bind(this));
        
        // Handle orientation change specifically for mobile
        window.addEventListener('orientationchange', () => {
            // Wait for orientation change to complete
            setTimeout(this.handleResize.bind(this), 300);
        });
    }
    
    handleResize() {
        // Get container dimensions
        const containerWidth = this.canvasContainer.parentElement.clientWidth - 40; // 20px padding on each side
        const containerHeight = Math.max(300, window.innerHeight * 0.6); // Use at least 300px or 60% of viewport height
        
        // Get template dimensions
        const templateWidth = this.templateData.width || 800;
        const templateHeight = this.templateData.height || 600;
        
        // Calculate scale to fit canvas in container while preserving aspect ratio
        const scaleByWidth = containerWidth / templateWidth;
        const scaleByHeight = containerHeight / templateHeight;
        
        // Use the smaller scale to ensure the entire canvas fits
        this.canvasScale = Math.min(scaleByWidth, scaleByHeight);
        
        // Apply proper scaling to maintain aspect ratio and center the canvas
        this.applyCanvasScaling();
        
        // Re-render canvas
        this.canvas.renderAll();
    }
    
    handleSelectionChange(e) {
        const selectedObject = e.selected[0];
        this.selectedObject = selectedObject;
        
        if (selectedObject.type === 'text' || selectedObject.type === 'i-text' || selectedObject.type === 'textbox') {
            this.showTextControls(selectedObject);
        } else {
            this.hideTextControls();
        }
    }
    
    handleSelectionCleared() {
        this.selectedObject = null;
        this.hideTextControls();
    }
    
    handleObjectModified() {
        this.saveState();
    }
    
    showTextControls(textObject) {
        const textControls = document.getElementById('text-controls');
        if (!textControls) return;
        
        // Clear existing controls
        textControls.innerHTML = '';
        
        // Create text input
        const textInput = document.createElement('div');
        textInput.className = 'mb-4';
        textInput.innerHTML = `
            <label class="block text-sm font-medium text-gray-700 mb-1">Text Content</label>
            <textarea id="text-content" class="w-full border border-gray-300 rounded p-2" rows="3">${textObject.text}</textarea>
        `;
        textControls.appendChild(textInput);
        
        // Add event listener to text input
        document.getElementById('text-content').addEventListener('input', (e) => {
            if (this.selectedObject) {
                this.selectedObject.set('text', e.target.value);
                this.canvas.renderAll();
            }
        });
        
        // Update font controls to match selected text
        const fontFamily = document.getElementById('font-family');
        const fontSize = document.getElementById('font-size');
        const boldButton = document.getElementById('bold-button');
        const italicButton = document.getElementById('italic-button');
        const underlineButton = document.getElementById('underline-button');
        const customColor = document.getElementById('custom-color');
        
        if (fontFamily) fontFamily.value = textObject.fontFamily;
        if (fontSize) fontSize.value = textObject.fontSize;
        
        // Update style buttons
        if (boldButton) boldButton.classList.toggle('bg-gray-400', textObject.fontWeight === 'bold');
        if (italicButton) italicButton.classList.toggle('bg-gray-400', textObject.fontStyle === 'italic');
        if (underlineButton) underlineButton.classList.toggle('bg-gray-400', textObject.underline);
        
        // Update color picker
        if (customColor) customColor.value = textObject.fill;
    }
    
    hideTextControls() {
        const textControls = document.getElementById('text-controls');
        if (textControls) {
            textControls.innerHTML = '<p class="text-gray-500 text-sm">Select a text element on the canvas to edit</p>';
        }
    }
    
    handleFontFamilyChange(e) {
        if (this.selectedObject && (this.selectedObject.type === 'text' || this.selectedObject.type === 'i-text' || this.selectedObject.type === 'textbox')) {
            this.selectedObject.set('fontFamily', e.target.value);
            this.canvas.renderAll();
            this.saveState();
        }
    }
    
    handleFontSizeChange(e) {
        if (this.selectedObject && (this.selectedObject.type === 'text' || this.selectedObject.type === 'i-text' || this.selectedObject.type === 'textbox')) {
            this.selectedObject.set('fontSize', parseInt(e.target.value, 10));
            this.canvas.renderAll();
            this.saveState();
        }
    }
    
    handleBoldClick() {
        if (this.selectedObject && (this.selectedObject.type === 'text' || this.selectedObject.type === 'i-text' || this.selectedObject.type === 'textbox')) {
            const isBold = this.selectedObject.fontWeight === 'bold';
            this.selectedObject.set('fontWeight', isBold ? 'normal' : 'bold');
            
            // Toggle button state
            const boldButton = document.getElementById('bold-button');
            if (boldButton) {
                boldButton.classList.toggle('bg-gray-400');
            }
            
            this.canvas.renderAll();
            this.saveState();
        }
    }
    
    handleItalicClick() {
        if (this.selectedObject && (this.selectedObject.type === 'text' || this.selectedObject.type === 'i-text' || this.selectedObject.type === 'textbox')) {
            const isItalic = this.selectedObject.fontStyle === 'italic';
            this.selectedObject.set('fontStyle', isItalic ? 'normal' : 'italic');
            
            // Toggle button state
            const italicButton = document.getElementById('italic-button');
            if (italicButton) {
                italicButton.classList.toggle('bg-gray-400');
            }
            
            this.canvas.renderAll();
            this.saveState();
        }
    }
    
    handleUnderlineClick() {
        if (this.selectedObject && (this.selectedObject.type === 'text' || this.selectedObject.type === 'i-text' || this.selectedObject.type === 'textbox')) {
            const isUnderlined = this.selectedObject.underline;
            this.selectedObject.set('underline', !isUnderlined);
            
            // Toggle button state
            const underlineButton = document.getElementById('underline-button');
            if (underlineButton) {
                underlineButton.classList.toggle('bg-gray-400');
            }
            
            this.canvas.renderAll();
            this.saveState();
        }
    }
    
    setTextColor(color) {
        if (this.selectedObject && (this.selectedObject.type === 'text' || this.selectedObject.type === 'i-text' || this.selectedObject.type === 'textbox')) {
            this.selectedObject.set('fill', color);
            
            // Update color picker
            const customColor = document.getElementById('custom-color');
            if (customColor) {
                customColor.value = color;
            }
            
            this.canvas.renderAll();
            this.saveState();
        }
    }
    
    resetTemplate() {
        if (confirm('Are you sure you want to reset the template? All changes will be lost.')) {
            // Clear canvas
            this.canvas.clear();
            
            // Reload template elements
            this.loadTemplateElements();
            
            // Reset history
            this.history = [];
            this.historyIndex = -1;
            this.saveState();
        }
    }
    
    previewTemplate() {
        // Create a modal to show the preview
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50';
        modal.style.padding = '20px';
        
        // Create preview container
        const previewContainer = document.createElement('div');
        previewContainer.className = 'bg-white rounded-lg p-4 max-w-4xl w-full max-h-screen overflow-auto';
        previewContainer.innerHTML = `
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-red-600 font-racing">Preview: ${this.templateData.name}</h2>
                <button id="close-preview" class="text-gray-500 hover:text-gray-700">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
            <div class="preview-image-container flex justify-center">
                <img id="preview-image" class="max-w-full max-h-[70vh] border" />
            </div>
            <div class="mt-4 flex justify-center">
                <button id="download-preview" class="bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded font-oswald">
                    Download Preview
                </button>
            </div>
        `;
        
        modal.appendChild(previewContainer);
        document.body.appendChild(modal);
        
        // Generate preview image
        this.canvas.discardActiveObject();
        this.canvas.renderAll();
        
        const dataURL = this.canvas.toDataURL({
            format: 'png',
            quality: 1
        });
        
        // Set preview image
        const previewImage = document.getElementById('preview-image');
        previewImage.src = dataURL;
        
        // Add event listeners
        document.getElementById('close-preview').addEventListener('click', () => {
            document.body.removeChild(modal);
        });
        
        document.getElementById('download-preview').addEventListener('click', () => {
            const link = document.createElement('a');
            link.download = `${this.templateData.name.replace(/\s+/g, '_')}_preview.png`;
            link.href = dataURL;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });
    }
    
    downloadAsImage() {
        // Deselect any active objects
        this.canvas.discardActiveObject();
        this.canvas.renderAll();
        
        // Generate image
        const dataURL = this.canvas.toDataURL({
            format: 'png',
            quality: 1
        });
        
        // Create download link
        const link = document.createElement('a');
        link.download = `${this.templateData.name.replace(/\s+/g, '_')}.png`;
        link.href = dataURL;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    downloadAsPDF() {
        // Deselect any active objects
        this.canvas.discardActiveObject();
        this.canvas.renderAll();
        
        // Generate image
        const dataURL = this.canvas.toDataURL({
            format: 'png',
            quality: 1
        });
        
        // Create PDF
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF({
            orientation: this.canvas.width > this.canvas.height ? 'landscape' : 'portrait',
            unit: 'px',
            format: [this.canvas.width, this.canvas.height]
        });
        
        // Add image to PDF
        pdf.addImage(
            dataURL, 
            'PNG', 
            0, 
            0, 
            this.canvas.width, 
            this.canvas.height
        );
        
        // Save PDF
        pdf.save(`${this.templateData.name.replace(/\s+/g, '_')}.pdf`);
    }
    
    copyToClipboard() {
        // Deselect any active objects
        this.canvas.discardActiveObject();
        this.canvas.renderAll();
        
        // Generate image
        const dataURL = this.canvas.toDataURL({
            format: 'png',
            quality: 1
        });
        
        // Create a temporary image element
        const img = document.createElement('img');
        img.src = dataURL;
        
        // Create a canvas element to draw the image
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = this.canvas.width;
        tempCanvas.height = this.canvas.height;
        
        // Wait for image to load
        img.onload = () => {
            // Draw image to canvas
            const ctx = tempCanvas.getContext('2d');
            ctx.drawImage(img, 0, 0);
            
            // Copy canvas content to clipboard
            tempCanvas.toBlob(blob => {
                try {
                    // Modern clipboard API
                    navigator.clipboard.write([
                        new ClipboardItem({
                            'image/png': blob
                        })
                    ]).then(() => {
                        alert('Image copied to clipboard!');
                    }).catch(err => {
                        console.error('Failed to copy image: ', err);
                        alert('Failed to copy image to clipboard. Your browser may not support this feature.');
                    });
                } catch (e) {
                    console.error('Clipboard API not supported: ', e);
                    alert('Your browser does not support copying images to clipboard.');
                }
            });
        };
    }
    
    saveTemplate() {
        // Deselect any active objects
        this.canvas.discardActiveObject();
        this.canvas.renderAll();
        
        // Get canvas JSON
        const json = JSON.stringify(this.canvas);
        
        // Create a blob
        const blob = new Blob([json], { type: 'application/json' });
        
        // Create download link
        const link = document.createElement('a');
        link.download = `${this.templateData.name.replace(/\s+/g, '_')}.json`;
        link.href = URL.createObjectURL(blob);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    saveState() {
        // Get current canvas state
        const json = JSON.stringify(this.canvas);
        
        // If we're not at the end of the history, truncate it
        if (this.historyIndex < this.history.length - 1) {
            this.history = this.history.slice(0, this.historyIndex + 1);
        }
        
        // Add current state to history
        this.history.push(json);
        this.historyIndex = this.history.length - 1;
        
        // Limit history size
        if (this.history.length > this.maxHistorySteps) {
            this.history.shift();
            this.historyIndex--;
        }
    }
    
    undo() {
        if (this.historyIndex > 0) {
            this.historyIndex--;
            this.loadState(this.history[this.historyIndex]);
        }
    }
    
    redo() {
        if (this.historyIndex < this.history.length - 1) {
            this.historyIndex++;
            this.loadState(this.history[this.historyIndex]);
        }
    }
    
    loadState(json) {
        // Clear canvas
        this.canvas.clear();
        
        // Load state from JSON
        this.canvas.loadFromJSON(json, () => {
            this.canvas.renderAll();
        });
    }
}

// Initialize editor when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const editor = new TemplateEditor();
    editor.initialize();
});
