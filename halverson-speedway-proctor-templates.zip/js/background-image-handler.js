/* Halverson Speedway Marketing Tool - Background Image Handler */

class BackgroundImageHandler {
    constructor(editor) {
        this.editor = editor;
        this.backgroundImages = [];
        this.maxFileSize = 8 * 1024 * 1024; // 8MB
        this.allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
        this.initialized = false;
        this.selectedBackgroundId = null;
        this.defaultBackgrounds = [
            {
                id: 'aerial_track_dark',
                name: 'Aerial Track (Dark)',
                src: '/assets/images/backgrounds/aerial_track_dark.jpg',
                type: 'default',
                category: 'track'
            },
            {
                id: 'aerial_track_dusk',
                name: 'Aerial Track (Dusk)',
                src: '/assets/images/backgrounds/aerial_track_dusk.jpg',
                type: 'default',
                category: 'track'
            },
            {
                id: 'checkered_flag_dark',
                name: 'Checkered Flag (Dark)',
                src: '/assets/images/backgrounds/checkered_flag_dark.jpg',
                type: 'default',
                category: 'racing'
            },
            {
                id: 'solid_black',
                name: 'Solid Black',
                src: '/assets/images/backgrounds/solid_black.jpg',
                type: 'default',
                category: 'solid'
            }
        ];
    }
    
    initialize() {
        // Create background controls
        this.createBackgroundControls();
        
        // Load previously uploaded background images from storage
        this.loadSavedBackgrounds();
        
        // Add default backgrounds to the library
        this.addDefaultBackgrounds();
        
        this.initialized = true;
    }
    
    createBackgroundControls() {
        // Find the control panel
        const controlPanel = document.querySelector('.control-panel');
        if (!controlPanel) return;
        
        // Create background section after image section or as first section if not found
        const imageSection = controlPanel.querySelector('.mb-6:nth-child(4)') || controlPanel.querySelector('.mb-6:first-child');
        if (!imageSection) return;
        
        // Create background section
        const backgroundSection = document.createElement('div');
        backgroundSection.className = 'mb-6';
        backgroundSection.innerHTML = `
            <h3 class="font-bold mb-2 font-oswald">Background</h3>
            <div id="background-controls">
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Background Type</label>
                    <div class="grid grid-cols-3 gap-2 mb-2">
                        <button id="bg-type-aerial" class="px-2 py-1 bg-gray-200 text-gray-800 text-sm rounded hover:bg-red-600 hover:text-white">
                            Aerial Track
                        </button>
                        <button id="bg-type-texture" class="px-2 py-1 bg-gray-200 text-gray-800 text-sm rounded hover:bg-red-600 hover:text-white">
                            Texture
                        </button>
                        <button id="bg-type-solid" class="px-2 py-1 bg-gray-200 text-gray-800 text-sm rounded hover:bg-red-600 hover:text-white">
                            Solid Color
                        </button>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Upload Background Image</label>
                    <div class="flex items-center">
                        <label class="flex flex-col items-center px-4 py-2 bg-white text-red-600 rounded-lg border border-red-600 cursor-pointer hover:bg-red-600 hover:text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0l-4 4m4-4v12" />
                            </svg>
                            <span class="mt-1 text-sm">Select Background</span>
                            <input id="background-upload" type="file" class="hidden" accept="image/*" />
                        </label>
                    </div>
                    <p class="text-xs text-gray-500 mt-1">Recommended: Aerial track photos with dark overlay for best results</p>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Background Library</label>
                    <div id="background-library" class="grid grid-cols-3 gap-2 max-h-40 overflow-y-auto p-2 bg-gray-100 rounded">
                        <p class="text-gray-500 text-sm col-span-3">Loading backgrounds...</p>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Background Darkness</label>
                    <div class="flex items-center">
                        <input type="range" id="background-darkness" min="0" max="80" value="30" class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer">
                        <span id="darkness-value" class="ml-2 text-sm">30%</span>
                    </div>
                </div>
                
                <div id="selected-background-controls" class="hidden">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Selected Background</label>
                    <div class="flex items-center space-x-2">
                        <button id="apply-selected-background" class="px-2 py-1 bg-red-600 text-white text-sm rounded">
                            Apply to Canvas
                        </button>
                        <button id="remove-selected-background" class="px-2 py-1 bg-gray-200 text-gray-800 text-sm rounded">
                            Remove
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        // Insert after image section or at the beginning
        if (imageSection) {
            imageSection.after(backgroundSection);
        } else {
            controlPanel.prepend(backgroundSection);
        }
        
        // Add event listeners
        this.setupEventListeners();
    }
    
    setupEventListeners() {
        // Background type buttons
        document.getElementById('bg-type-aerial')?.addEventListener('click', () => this.filterBackgroundsByType('track'));
        document.getElementById('bg-type-texture')?.addEventListener('click', () => this.filterBackgroundsByType('racing'));
        document.getElementById('bg-type-solid')?.addEventListener('click', () => this.filterBackgroundsByType('solid'));
        
        // Background upload
        const backgroundUpload = document.getElementById('background-upload');
        if (backgroundUpload) {
            backgroundUpload.addEventListener('change', this.handleBackgroundUpload.bind(this));
        }
        
        // Apply selected background button
        const applySelectedBackground = document.getElementById('apply-selected-background');
        if (applySelectedBackground) {
            applySelectedBackground.addEventListener('click', this.applySelectedBackground.bind(this));
        }
        
        // Remove selected background button
        const removeSelectedBackground = document.getElementById('remove-selected-background');
        if (removeSelectedBackground) {
            removeSelectedBackground.addEventListener('click', this.removeSelectedBackground.bind(this));
        }
        
        // Background darkness slider
        const backgroundDarkness = document.getElementById('background-darkness');
        if (backgroundDarkness) {
            backgroundDarkness.addEventListener('input', this.handleDarknessChange.bind(this));
        }
    }
    
    filterBackgroundsByType(category) {
        // Update button styles
        document.getElementById('bg-type-aerial')?.classList.remove('bg-red-600', 'text-white');
        document.getElementById('bg-type-aerial')?.classList.add('bg-gray-200', 'text-gray-800');
        
        document.getElementById('bg-type-texture')?.classList.remove('bg-red-600', 'text-white');
        document.getElementById('bg-type-texture')?.classList.add('bg-gray-200', 'text-gray-800');
        
        document.getElementById('bg-type-solid')?.classList.remove('bg-red-600', 'text-white');
        document.getElementById('bg-type-solid')?.classList.add('bg-gray-200', 'text-gray-800');
        
        // Highlight selected button
        if (category === 'track') {
            document.getElementById('bg-type-aerial')?.classList.remove('bg-gray-200', 'text-gray-800');
            document.getElementById('bg-type-aerial')?.classList.add('bg-red-600', 'text-white');
        } else if (category === 'racing') {
            document.getElementById('bg-type-texture')?.classList.remove('bg-gray-200', 'text-gray-800');
            document.getElementById('bg-type-texture')?.classList.add('bg-red-600', 'text-white');
        } else if (category === 'solid') {
            document.getElementById('bg-type-solid')?.classList.remove('bg-gray-200', 'text-gray-800');
            document.getElementById('bg-type-solid')?.classList.add('bg-red-600', 'text-white');
        }
        
        // Filter backgrounds
        this.updateBackgroundLibrary(category);
    }
    
    handleBackgroundUpload(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        // Check file size
        if (file.size > this.maxFileSize) {
            notifications.show('Image is too large. Maximum size is 8MB.', 'error');
            return;
        }
        
        // Check file type
        if (!this.allowedTypes.includes(file.type)) {
            notifications.show('Invalid file type. Please upload a JPEG, PNG, or WebP image.', 'error');
            return;
        }
        
        // Read file
        const reader = new FileReader();
        reader.onload = (event) => {
            const backgroundData = {
                id: 'bg_' + utils.generateId(),
                name: file.name,
                src: event.target.result,
                type: 'custom',
                category: 'track', // Default to track category for uploaded backgrounds
                size: file.size,
                date: new Date().toISOString()
            };
            
            // Add to backgrounds
            this.backgroundImages.push(backgroundData);
            
            // Save to storage
            this.saveBackgroundsToStorage();
            
            // Update background library
            this.updateBackgroundLibrary();
            
            // Reset file input
            e.target.value = '';
            
            // Show notification
            notifications.show('Background image uploaded successfully', 'success');
        };
        
        reader.readAsDataURL(file);
    }
    
    updateBackgroundLibrary(filterCategory = null) {
        const backgroundLibrary = document.getElementById('background-library');
        if (!backgroundLibrary) return;
        
        // Clear library
        backgroundLibrary.innerHTML = '';
        
        // Combine default and custom backgrounds
        const allBackgrounds = [...this.defaultBackgrounds, ...this.backgroundImages];
        
        // Filter by category if specified
        const filteredBackgrounds = filterCategory 
            ? allBackgrounds.filter(bg => bg.category === filterCategory)
            : allBackgrounds;
        
        if (filteredBackgrounds.length === 0) {
            backgroundLibrary.innerHTML = '<p class="text-gray-500 text-sm col-span-3">No backgrounds available</p>';
            return;
        }
        
        // Add backgrounds to library
        filteredBackgrounds.forEach(background => {
            const backgroundElement = document.createElement('div');
            backgroundElement.className = 'background-item relative cursor-pointer border hover:border-red-600';
            backgroundElement.dataset.id = background.id;
            backgroundElement.innerHTML = `
                <img src="${background.src}" alt="${background.name}" class="w-full h-16 object-cover">
                <div class="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white text-xs p-1 truncate">
                    ${background.name}
                </div>
            `;
            
            // Add click event
            backgroundElement.addEventListener('click', () => {
                // Remove selected class from all backgrounds
                document.querySelectorAll('.background-item').forEach(item => {
                    item.classList.remove('border-red-600');
                    item.classList.add('border-gray-300');
                });
                
                // Add selected class to clicked background
                backgroundElement.classList.remove('border-gray-300');
                backgroundElement.classList.add('border-red-600');
                
                // Show selected background controls
                const selectedBackgroundControls = document.getElementById('selected-background-controls');
                if (selectedBackgroundControls) {
                    selectedBackgroundControls.classList.remove('hidden');
                }
                
                // Set selected background
                this.selectedBackgroundId = background.id;
            });
            
            backgroundLibrary.appendChild(backgroundElement);
        });
    }
    
    applySelectedBackground() {
        if (!this.selectedBackgroundId) {
            notifications.show('Please select a background first', 'error');
            return;
        }
        
        // Find selected background
        const background = [...this.defaultBackgrounds, ...this.backgroundImages]
            .find(bg => bg.id === this.selectedBackgroundId);
            
        if (!background) return;
        
        // Get darkness value
        const darknessValue = parseInt(document.getElementById('background-darkness')?.value || '30');
        const darknessOpacity = darknessValue / 100;
        
        // Apply background to canvas
        this.applyBackgroundToCanvas(background.src, darknessOpacity);
    }
    
    applyBackgroundToCanvas(src, darknessOpacity = 0.3) {
        fabric.Image.fromURL(src, img => {
            // Get canvas dimensions
            const canvas = this.editor.canvas;
            const canvasWidth = canvas.width;
            const canvasHeight = canvas.height;
            
            // Calculate scale to fill the entire canvas
            const scaleX = canvasWidth / img.width;
            const scaleY = canvasHeight / img.height;
            
            // Use the larger scale to ensure the image fills the canvas
            const scale = Math.max(scaleX, scaleY);
            
            // Apply the background image
            canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas), {
                scaleX: scale,
                scaleY: scale,
                // Center the image if it's larger than the canvas
                left: (canvasWidth - img.width * scale) / 2,
                top: (canvasHeight - img.height * scale) / 2
            });
            
            // Add a dark overlay if darkness is specified
            if (darknessOpacity > 0) {
                // Remove any existing overlay
                const existingOverlay = canvas.getObjects().find(obj => obj.id === 'background_overlay');
                if (existingOverlay) {
                    canvas.remove(existingOverlay);
                }
                
                // Create dark overlay
                const overlay = new fabric.Rect({
                    left: 0,
                    top: 0,
                    width: canvasWidth,
                    height: canvasHeight,
                    fill: '#000000',
                    opacity: darknessOpacity,
                    selectable: false,
                    evented: false,
                    id: 'background_overlay'
                });
                
                // Add to canvas at the bottom of the stack
                canvas.add(overlay);
                overlay.moveTo(0); // Move to bottom
                
                // Add custom properties
                overlay.toObject = (function(toObject) {
                    return function() {
                        return fabric.util.object.extend(toObject.call(this), {
                            id: this.id
                        });
                    };
                })(overlay.toObject);
            }
            
            // Render canvas
            canvas.renderAll();
            
            // Save state
            this.editor.saveState();
            
            // Show notification
            notifications.show('Background applied successfully', 'success');
        });
    }
    
    handleDarknessChange(e) {
        const value = e.target.value;
        document.getElementById('darkness-value').textContent = `${value}%`;
        
        // If a background is already selected, update the preview
        if (this.selectedBackgroundId) {
            // Find selected background
            const background = [...this.defaultBackgrounds, ...this.backgroundImages]
                .find(bg => bg.id === this.selectedBackgroundId);
                
            if (background) {
                // Update the background item preview with darkness overlay
                const backgroundItem = document.querySelector(`.background-item[data-id="${this.selectedBackgroundId}"]`);
                if (backgroundItem) {
                    const img = backgroundItem.querySelector('img');
                    if (img) {
                        img.style.filter = `brightness(${100 - value}%)`;
                    }
                }
            }
        }
    }
    
    removeSelectedBackground() {
        if (!this.selectedBackgroundId) {
            notifications.show('Please select a background first', 'error');
            return;
        }
        
        // Check if it's a default background
        const isDefault = this.defaultBackgrounds.some(bg => bg.id === this.selectedBackgroundId);
        if (isDefault) {
            notifications.show('Default backgrounds cannot be removed', 'error');
            return;
        }
        
        // Confirm deletion
        if (confirm('Are you sure you want to remove this background from your library?')) {
            // Remove from backgrounds
            this.backgroundImages = this.backgroundImages.filter(bg => bg.id !== this.selectedBackgroundId);
            
            // Save to storage
            this.saveBackgroundsToStorage();
            
            // Update background library
            this.updateBackgroundLibrary();
            
            // Hide selected background controls
            const selectedBackgroundControls = document.getElementById('selected-background-controls');
            if (selectedBackgroundControls) {
                selectedBackgroundControls.classList.add('hidden');
            }
            
            // Clear selected background
            this.selectedBackgroundId = null;
            
            // Show notification
            notifications.show('Background removed from library', 'success');
        }
    }
    
    saveBackgroundsToStorage() {
        // Save only the last 10 backgrounds to prevent storage issues
        const backgroundsToSave = this.backgroundImages.slice(-10);
        storageManager.save('backgroundImages', backgroundsToSave);
    }
    
    loadSavedBackgrounds() {
        const savedBackgrounds = storageManager.load('backgroundImages');
        if (savedBackgrounds && Array.isArray(savedBackgrounds)) {
            this.backgroundImages = savedBackgrounds;
        }
    }
    
    addDefaultBackgrounds() {
        // Check if default backgrounds directory exists
        // This is just a placeholder - in a real implementation, you would need to
        // ensure these images exist in the assets directory
        
        // Update the background library with all backgrounds
        this.updateBackgroundLibrary();
    }
}

// Initialize background image handler when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Wait for TemplateEditor to initialize
    const checkEditor = setInterval(() => {
        if (window.templateEditor && window.templateEditor.initialized) {
            clearInterval(checkEditor);
            
            // Initialize background image handler
            const backgroundImageHandler = new BackgroundImageHandler(window.templateEditor);
            backgroundImageHandler.initialize();
        }
    }, 100);
});
