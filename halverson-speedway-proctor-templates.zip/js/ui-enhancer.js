/* Halverson Speedway Marketing Tool - UI Improvements for Proctor-Style Templates */

/**
 * This file contains UI enhancements for the Halverson Speedway Marketing Tool
 * to better support Proctor-style templates with aerial track photos and
 * improved visual hierarchy.
 */

class UIEnhancer {
    constructor() {
        this.initialized = false;
    }
    
    initialize() {
        // Add template style selector
        this.addTemplateStyleSelector();
        
        // Add color scheme presets
        this.addColorSchemePresets();
        
        // Add quick layout options
        this.addQuickLayoutOptions();
        
        // Add mobile preview toggle
        this.addMobilePreviewToggle();
        
        this.initialized = true;
    }
    
    addTemplateStyleSelector() {
        // Find the template selection area on the index page
        const templateCategories = document.querySelectorAll('.template-category');
        if (templateCategories.length === 0) return;
        
        // Add style filter at the top of the page
        const mainContent = document.querySelector('.main-content');
        if (!mainContent) return;
        
        const styleFilter = document.createElement('div');
        styleFilter.className = 'style-filter mb-8';
        styleFilter.innerHTML = `
            <h2 class="text-2xl font-bold mb-4 font-oswald">Template Style</h2>
            <div class="flex flex-wrap gap-4">
                <button class="style-btn active px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-100" data-style="all">
                    All Styles
                </button>
                <button class="style-btn px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-100" data-style="standard">
                    Standard
                </button>
                <button class="style-btn px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-100" data-style="proctor">
                    Proctor Style
                </button>
            </div>
        `;
        
        // Insert at the beginning of main content
        mainContent.insertBefore(styleFilter, mainContent.firstChild);
        
        // Add data-style attributes to template cards
        document.querySelectorAll('.template-card').forEach(card => {
            const templateName = card.querySelector('h3').textContent.toLowerCase();
            if (templateName.includes('proctor')) {
                card.dataset.style = 'proctor';
            } else {
                card.dataset.style = 'standard';
            }
        });
        
        // Add event listeners to style buttons
        document.querySelectorAll('.style-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                // Update active button
                document.querySelectorAll('.style-btn').forEach(b => b.classList.remove('active', 'bg-red-600', 'text-white'));
                btn.classList.add('active', 'bg-red-600', 'text-white');
                
                // Filter templates
                const style = btn.dataset.style;
                document.querySelectorAll('.template-card').forEach(card => {
                    if (style === 'all' || card.dataset.style === style) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }
    
    addColorSchemePresets() {
        // Only add to editor page
        if (!window.templateEditor) return;
        
        // Find the color picker section
        const colorSection = document.querySelector('.control-panel div:nth-child(2)');
        if (!colorSection) return;
        
        // Create color scheme presets
        const colorPresets = document.createElement('div');
        colorPresets.className = 'mb-4';
        colorPresets.innerHTML = `
            <label class="block text-sm font-medium text-gray-700 mb-1">Color Schemes</label>
            <div class="grid grid-cols-3 gap-2">
                <button class="color-preset px-2 py-1 text-xs rounded border border-gray-300 hover:bg-gray-100" data-colors='{"primary":"#FFDD00","secondary":"#FFFFFF","accent":"#C0C0C0","background":"#000000"}'>
                    Proctor Dark
                </button>
                <button class="color-preset px-2 py-1 text-xs rounded border border-gray-300 hover:bg-gray-100" data-colors='{"primary":"#D12026","secondary":"#FFFFFF","accent":"#000000","background":"#FFDD00"}'>
                    Halverson Original
                </button>
                <button class="color-preset px-2 py-1 text-xs rounded border border-gray-300 hover:bg-gray-100" data-colors='{"primary":"#FFDD00","secondary":"#FFFFFF","accent":"#D12026","background":"#333333"}'>
                    Racing Dark
                </button>
            </div>
        `;
        
        // Insert after color picker
        colorSection.appendChild(colorPresets);
        
        // Add event listeners to color presets
        document.querySelectorAll('.color-preset').forEach(preset => {
            preset.addEventListener('click', () => {
                const colors = JSON.parse(preset.dataset.colors);
                
                // Apply colors to selected elements
                const activeObject = templateEditor.canvas.getActiveObject();
                if (activeObject) {
                    if (activeObject.type === 'text') {
                        // For text elements, apply the primary color
                        activeObject.set('fill', colors.primary);
                        templateEditor.canvas.renderAll();
                        templateEditor.saveState();
                    } else if (activeObject.type === 'rect') {
                        // For shape elements, apply the accent color
                        activeObject.set('fill', colors.accent);
                        templateEditor.canvas.renderAll();
                        templateEditor.saveState();
                    }
                } else {
                    // If no element is selected, show a notification
                    notifications.show('Select an element to apply colors', 'info');
                }
            });
        });
    }
    
    addQuickLayoutOptions() {
        // Only add to editor page
        if (!window.templateEditor) return;
        
        // Find the layout section or create one
        let layoutSection = document.querySelector('#layout-controls');
        if (!layoutSection) {
            // Create layout section
            layoutSection = document.createElement('div');
            layoutSection.id = 'layout-controls';
            layoutSection.className = 'mb-6';
            layoutSection.innerHTML = `
                <h3 class="font-bold mb-2 font-oswald">Layout</h3>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Quick Layouts</label>
                    <div class="grid grid-cols-2 gap-2">
                        <button id="layout-centered" class="px-2 py-1 bg-gray-200 text-gray-800 text-sm rounded hover:bg-red-600 hover:text-white">
                            Centered Title
                        </button>
                        <button id="layout-results" class="px-2 py-1 bg-gray-200 text-gray-800 text-sm rounded hover:bg-red-600 hover:text-white">
                            Race Results
                        </button>
                        <button id="layout-event" class="px-2 py-1 bg-gray-200 text-gray-800 text-sm rounded hover:bg-red-600 hover:text-white">
                            Event Details
                        </button>
                        <button id="layout-schedule" class="px-2 py-1 bg-gray-200 text-gray-800 text-sm rounded hover:bg-red-600 hover:text-white">
                            Race Schedule
                        </button>
                    </div>
                </div>
            `;
            
            // Find the control panel
            const controlPanel = document.querySelector('.control-panel');
            if (controlPanel) {
                // Insert after background section
                const backgroundSection = controlPanel.querySelector('div:nth-child(5)') || controlPanel.querySelector('div:last-child');
                if (backgroundSection) {
                    backgroundSection.after(layoutSection);
                } else {
                    controlPanel.appendChild(layoutSection);
                }
            }
        }
        
        // Add event listeners to layout buttons
        document.getElementById('layout-centered')?.addEventListener('click', () => {
            this.applyLayout('centered');
        });
        
        document.getElementById('layout-results')?.addEventListener('click', () => {
            this.applyLayout('results');
        });
        
        document.getElementById('layout-event')?.addEventListener('click', () => {
            this.applyLayout('event');
        });
        
        document.getElementById('layout-schedule')?.addEventListener('click', () => {
            this.applyLayout('schedule');
        });
    }
    
    applyLayout(layoutType) {
        if (!window.templateEditor) return;
        
        const canvas = templateEditor.canvas;
        const canvasWidth = canvas.width;
        const canvasHeight = canvas.height;
        
        // Get all text objects
        const textObjects = canvas.getObjects().filter(obj => obj.type === 'text');
        if (textObjects.length === 0) {
            notifications.show('No text elements found', 'error');
            return;
        }
        
        switch (layoutType) {
            case 'centered':
                // Find title-like text (largest font size)
                const titleObject = textObjects.reduce((prev, current) => {
                    return (prev.fontSize > current.fontSize) ? prev : current;
                });
                
                // Center the title
                titleObject.set({
                    left: canvasWidth / 2,
                    top: canvasHeight * 0.3,
                    textAlign: 'center',
                    originX: 'center',
                    originY: 'center'
                });
                
                // Arrange other text elements below
                const otherTexts = textObjects.filter(obj => obj !== titleObject);
                let currentTop = canvasHeight * 0.45;
                
                otherTexts.forEach(text => {
                    text.set({
                        left: canvasWidth / 2,
                        top: currentTop,
                        textAlign: 'center',
                        originX: 'center',
                        originY: 'center'
                    });
                    currentTop += text.height * text.scaleY + 20;
                });
                break;
                
            case 'results':
                // Find title and date
                const resultsTitle = textObjects.find(obj => obj.text.includes('RESULTS') || obj.text.includes('RACE'));
                const dateText = textObjects.find(obj => /\d{1,2}([\/\-\.])\d{1,2}\1\d{2,4}/.test(obj.text) || obj.text.includes('202'));
                
                if (resultsTitle) {
                    resultsTitle.set({
                        left: canvasWidth / 2,
                        top: canvasHeight * 0.15,
                        textAlign: 'center',
                        originX: 'center',
                        originY: 'center',
                        fontSize: 80,
                        fill: '#FFDD00'
                    });
                }
                
                if (dateText) {
                    dateText.set({
                        left: canvasWidth / 2,
                        top: canvasHeight * 0.25,
                        textAlign: 'center',
                        originX: 'center',
                        originY: 'center',
                        fontSize: 40,
                        fill: '#FFFFFF'
                    });
                }
                
                // Find division text
                const divisionText = textObjects.find(obj => 
                    obj.text.includes('DIVISION') || 
                    obj.text.includes('CLASS') || 
                    obj.text.includes('MODEL')
                );
                
                if (divisionText) {
                    divisionText.set({
                        left: canvasWidth / 2,
                        top: canvasHeight * 0.35,
                        textAlign: 'center',
                        originX: 'center',
                        originY: 'center',
                        fontSize: 50,
                        fill: '#C0C0C0'
                    });
                }
                
                // Find place texts
                const placeTexts = textObjects.filter(obj => 
                    obj.text.includes('Place') || 
                    obj.text.includes('1st') || 
                    obj.text.includes('2nd') || 
                    obj.text.includes('3rd')
                );
                
                let placeTop = canvasHeight * 0.45;
                placeTexts.forEach(text => {
                    text.set({
                        left: canvasWidth / 2,
                        top: placeTop,
                        textAlign: 'center',
                        originX: 'center',
                        originY: 'center',
                        fontSize: 36,
                        fill: '#FFFFFF'
                    });
                    placeTop += 50;
                });
                break;
                
            case 'event':
                // Find event title
                const eventTitle = textObjects.reduce((prev, current) => {
                    return (prev.fontSize > current.fontSize) ? prev : current;
                });
                
                eventTitle.set({
                    left: canvasWidth / 2,
                    top: canvasHeight * 0.25,
                    textAlign: 'center',
                    originX: 'center',
                    originY: 'center',
                    fontSize: 100,
                    fill: '#FFDD00'
                });
                
                // Find date
                const eventDate = textObjects.find(obj => /\d{1,2}([\/\-\.])\d{1,2}\1\d{2,4}/.test(obj.text) || obj.text.includes('202'));
                
                if (eventDate) {
                    eventDate.set({
                        left: canvasWidth / 2,
                        top: canvasHeight * 0.4,
                        textAlign: 'center',
                        originX: 'center',
                        originY: 'center',
                        fontSize: 50,
                        fill: '#FFFFFF'
                    });
                }
                
                // Find time/details texts
                const detailTexts = textObjects.filter(obj => 
                    obj !== eventTitle && 
                    obj !== eventDate && 
                    !obj.text.includes('SPEEDWAY')
                );
                
                let detailTop = canvasHeight * 0.5;
                detailTexts.forEach(text => {
                    text.set({
                        left: canvasWidth / 2,
                        top: detailTop,
                        textAlign: 'center',
                        originX: 'center',
                        originY: 'center',
                        fontSize: 36,
                        fill: '#FFFFFF'
                    });
                    detailTop += 50;
                });
                break;
                
            case 'schedule':
                // Find schedule title
                const scheduleTitle = textObjects.find(obj => 
                    obj.text.includes('SCHEDULE') || 
                    obj.text.includes('CALENDAR')
                ) || textObjects.reduce((prev, current) => {
                    return (prev.fontSize > current.fontSize) ? prev : current;
                });
                
                scheduleTitle.set({
                    left: canvasWidth / 2,
                    top: canvasHeight * 0.15,
                    textAlign: 'center',
                    originX: 'center',
                    originY: 'center',
                    fontSize: 80,
                    fill: '#FFDD00'
                });
                
                // Find year
                const yearText = textObjects.find(obj => /202\d/.test(obj.text));
                
                if (yearText) {
                    yearText.set({
                        left: canvasWidth / 2,
                        top: canvasHeight * 0.25,
                        textAlign: 'center',
                        originX: 'center',
                        originY: 'center',
                        fontSize: 50,
                        fill: '#FFFFFF'
                    });
                }
                
                // Arrange other texts in two columns
                const scheduleItems = textObjects.filter(obj => 
                    obj !== scheduleTitle && 
                    obj !== yearText && 
                    !obj.text.includes('SPEEDWAY')
                );
                
                const midPoint = Math.ceil(scheduleItems.length / 2);
                const leftColumn = scheduleItems.slice(0, midPoint);
                const rightColumn = scheduleItems.slice(midPoint);
                
                let leftTop = canvasHeight * 0.35;
                leftColumn.forEach(text => {
                    text.set({
                        left: canvasWidth * 0.3,
                        top: leftTop,
                        textAlign: 'center',
                        originX: 'center',
                        originY: 'center',
                        fontSize: 30,
                        fill: '#FFFFFF'
                    });
                    leftTop += 40;
                });
                
                let rightTop = canvasHeight * 0.35;
                rightColumn.forEach(text => {
                    text.set({
                        left: canvasWidth * 0.7,
                        top: rightTop,
                        textAlign: 'center',
                        originX: 'center',
                        originY: 'center',
                        fontSize: 30,
                        fill: '#FFFFFF'
                    });
                    rightTop += 40;
                });
                break;
        }
        
        canvas.renderAll();
        templateEditor.saveState();
        notifications.show(`Applied ${layoutType} layout`, 'success');
    }
    
    addMobilePreviewToggle() {
        // Only add to editor page
        if (!window.templateEditor) return;
        
        // Create mobile preview toggle
        const previewToggle = document.createElement('div');
        previewToggle.className = 'mobile-preview-toggle fixed bottom-4 right-4 z-50';
        previewToggle.innerHTML = `
            <button id="toggle-mobile-preview" class="flex items-center justify-center w-12 h-12 bg-red-600 text-white rounded-full shadow-lg hover:bg-red-700 focus:outline-none">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                </svg>
            </button>
        `;
        
        // Add to body
        document.body.appendChild(previewToggle);
        
        // Create mobile preview container
        const previewContainer = document.createElement('div');
        previewContainer.className = 'mobile-preview-container fixed inset-0 bg-black bg-opacity-75 z-40 hidden flex items-center justify-center';
        previewContainer.innerHTML = `
            <div class="relative bg-white rounded-xl overflow-hidden shadow-2xl" style="width: 375px; height: 667px;">
                <div class="absolute top-0 left-0 right-0 h-6 bg-black"></div>
                <div class="absolute bottom-0 left-0 right-0 h-6 bg-black"></div>
                <div id="mobile-preview-content" class="w-full h-full pt-6 pb-6 overflow-hidden">
                    <!-- Preview content will be inserted here -->
                </div>
                <button id="close-mobile-preview" class="absolute top-2 right-2 text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        `;
        
        // Add to body
        document.body.appendChild(previewContainer);
        
        // Add event listeners
        document.getElementById('toggle-mobile-preview')?.addEventListener('click', () => {
            this.showMobilePreview();
        });
        
        document.getElementById('close-mobile-preview')?.addEventListener('click', () => {
            document.querySelector('.mobile-preview-container').classList.add('hidden');
        });
    }
    
    showMobilePreview() {
        if (!window.templateEditor) return;
        
        // Get canvas data URL
        const dataURL = templateEditor.canvas.toDataURL({
            format: 'png',
            quality: 1
        });
        
        // Show preview container
        const previewContainer = document.querySelector('.mobile-preview-container');
        previewContainer.classList.remove('hidden');
        
        // Set preview content
        const previewContent = document.getElementById('mobile-preview-content');
        previewContent.innerHTML = `
            <div class="w-full h-full flex items-center justify-center bg-gray-100">
                <img src="${dataURL}" alt="Mobile Preview" class="max-w-full max-h-full object-contain">
            </div>
        `;
    }
}

// Initialize UI enhancer when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const uiEnhancer = new UIEnhancer();
    
    // For editor page, wait for editor to initialize
    if (window.location.pathname.includes('editor.html')) {
        const checkEditor = setInterval(() => {
            if (window.templateEditor && window.templateEditor.initialized) {
                clearInterval(checkEditor);
                uiEnhancer.initialize();
            }
        }, 100);
    } else {
        // For other pages, initialize immediately
        uiEnhancer.initialize();
    }
});
