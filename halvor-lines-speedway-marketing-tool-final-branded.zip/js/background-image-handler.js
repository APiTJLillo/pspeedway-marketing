/* Halvor Lines Speedway Marketing Tool - Background Image Handler */
document.addEventListener("DOMContentLoaded", () => {
    const templateEditor = window.templateEditor;
    if (!templateEditor) {
        console.error("TemplateEditor not found. Background Image Handler cannot initialize.");
        return;
    }

    const backgroundTypeButtons = document.querySelectorAll("[data-background-type]");
    const backgroundLibraryContainer = document.getElementById("background-library-container");
    const backgroundDarknessSlider = document.getElementById("background-darkness-slider");
    const backgroundDarknessValue = document.getElementById("background-darkness-value");
    const customBackgroundUpload = document.getElementById("custom-background-upload");

    let currentBackgroundType = "aerial-track"; // Default type
    let currentDarkness = 0.3; // Default darkness

    const defaultBackgrounds = {
        "aerial-track": [
            { name: "Aerial Track Dark", url: "/assets/images/backgrounds/aerial_track_dark.jpg" },
            { name: "Aerial Track Dusk", url: "/assets/images/backgrounds/aerial_track_dusk.jpg" },
            { name: "Checkered Flag Dark", url: "/assets/images/backgrounds/checkered_flag_dark.jpg" }
        ],
        "texture": [
            { name: "Dark Texture 1", url: "/assets/images/backgrounds/texture_dark_1.jpg" },
            { name: "Metal Plate", url: "/assets/images/backgrounds/texture_metal_plate.jpg" }
        ],
        "solid-color": [
            { name: "Black", color: "#000000" },
            { name: "Halverson Red", color: "#D12026" },
            { name: "Dark Gray", color: "#333333" }
        ]
    };

    function renderBackgroundLibrary() {
        if (!backgroundLibraryContainer) return;
        backgroundLibraryContainer.innerHTML = "";
        const backgrounds = defaultBackgrounds[currentBackgroundType] || [];

        backgrounds.forEach(bg => {
            const thumb = document.createElement("img");
            thumb.classList.add("bg-thumbnail", "w-16", "h-10", "object-cover", "rounded", "cursor-pointer", "border-2", "border-transparent", "hover:border-red-500");
            thumb.alt = bg.name;
            if (bg.url) {
                thumb.src = bg.url;
                thumb.addEventListener("click", () => {
                    templateEditor.setBackgroundImage(bg.url, currentDarkness);
                    updateSelectedThumbnail(thumb);
                });
            } else if (bg.color) {
                thumb.style.backgroundColor = bg.color;
                thumb.src = `data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7`; // Transparent pixel
                thumb.addEventListener("click", () => {
                    templateEditor.canvas.setBackgroundColor(bg.color, templateEditor.canvas.renderAll.bind(templateEditor.canvas));
                    templateEditor.canvas.setBackgroundImage(null, templateEditor.canvas.renderAll.bind(templateEditor.canvas)); // Clear image bg
                    updateSelectedThumbnail(thumb);
                });
            }
            backgroundLibraryContainer.appendChild(thumb);
        });
    }

    function updateSelectedThumbnail(selectedThumb) {
        document.querySelectorAll(".bg-thumbnail.selected").forEach(t => t.classList.remove("selected", "border-red-500"));
        if (selectedThumb) {
            selectedThumb.classList.add("selected", "border-red-500");
        }
    }

    if (backgroundTypeButtons) {
        backgroundTypeButtons.forEach(button => {
            button.addEventListener("click", () => {
                currentBackgroundType = button.dataset.backgroundType;
                backgroundTypeButtons.forEach(btn => btn.classList.remove("bg-red-600", "text-white"));
                button.classList.add("bg-red-600", "text-white");
                renderBackgroundLibrary();
            });
        });
    }

    if (backgroundDarknessSlider && backgroundDarknessValue) {
        backgroundDarknessSlider.value = currentDarkness * 100;
        backgroundDarknessValue.textContent = `${Math.round(currentDarkness * 100)}%`;
        backgroundDarknessSlider.addEventListener("input", (event) => {
            currentDarkness = parseFloat(event.target.value) / 100;
            backgroundDarknessValue.textContent = `${event.target.value}%`;
            // Re-apply current background with new darkness
            const currentBgImage = templateEditor.canvas.backgroundImage;
            if (currentBgImage && currentBgImage.getSrc) {
                 templateEditor.setBackgroundImage(currentBgImage.getSrc(), currentDarkness);
            } else if (templateEditor.canvas.backgroundColor && currentBackgroundType === "solid-color") {
                // For solid colors, darkness doesn't apply in the same way, but we keep the value
            } else {
                 // If no image, but darkness changed, and not solid color, try to apply to a default if one was selected
                const selectedThumb = backgroundLibraryContainer ? backgroundLibraryContainer.querySelector(".bg-thumbnail.selected") : null;
                if(selectedThumb && selectedThumb.src && !selectedThumb.src.startsWith("data:image")){
                    templateEditor.setBackgroundImage(selectedThumb.src, currentDarkness);
                }
            }
        });
    }

    if (customBackgroundUpload) {
        customBackgroundUpload.addEventListener("change", (event) => {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    templateEditor.setBackgroundImage(e.target.result, currentDarkness);
                    updateSelectedThumbnail(null); // Clear library selection
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    // Initial render
    if (backgroundTypeButtons.length > 0) {
        backgroundTypeButtons[0].click(); // Click the first type to initialize
    } else {
        renderBackgroundLibrary(); // Fallback if no type buttons
    }

    // Expose a function to TemplateEditor to set background from loaded template
    templateEditor.applyBackgroundFromData = function(backgroundData) {
        if (!backgroundData) return;

        if (backgroundData.type === "image" && backgroundData.url) {
            currentDarkness = backgroundData.darkness !== undefined ? backgroundData.darkness : 0.3;
            if (backgroundDarknessSlider) backgroundDarknessSlider.value = currentDarkness * 100;
            if (backgroundDarknessValue) backgroundDarknessValue.textContent = `${Math.round(currentDarkness * 100)}%`;
            this.setBackgroundImage(backgroundData.url, currentDarkness);
        } else if (backgroundData.type === "color" && backgroundData.color) {
            this.canvas.setBackgroundColor(backgroundData.color, this.canvas.renderAll.bind(this.canvas));
            this.canvas.setBackgroundImage(null, this.canvas.renderAll.bind(this.canvas));
        }
    };
});

