/* Halverson Speedway Marketing Tool - UI Enhancer */
document.addEventListener("DOMContentLoaded", () => {
    const templateEditor = window.templateEditor;
    if (!templateEditor) {
        console.error("TemplateEditor not found. UI Enhancer cannot initialize.");
        return;
    }

    // --- Color Scheme Presets ---
    const colorSchemeButtons = document.querySelectorAll("[data-color-scheme]");
    if (colorSchemeButtons) {
        colorSchemeButtons.forEach(button => {
            button.addEventListener("click", () => {
                const schemeName = button.dataset.colorScheme;
                applyColorScheme(schemeName);
                colorSchemeButtons.forEach(btn => btn.classList.remove("ring-2", "ring-red-500"));
                button.classList.add("ring-2", "ring-red-500");
            });
        });
    }

    function applyColorScheme(schemeName) {
        // This function would interact with templateEditor to change colors of elements
        // For now, it's a placeholder. Actual implementation depends on how templateEditor handles element styling.
        console.log(`Applying color scheme: ${schemeName}`);
        let primaryColor, secondaryColor, accentColor, backgroundColor, textColor;

        switch (schemeName) {
            case "proctor-dark":
                primaryColor = "#FFDD00"; // Yellow
                secondaryColor = "#FFFFFF"; // White
                accentColor = "#C0C0C0"; // Silver/Gray
                backgroundColor = "#000000"; // Black (often with image)
                textColor = "#FFFFFF";
                // Example: templateEditor.updateElementColors({ primary: primaryColor, text: textColor ... });
                // Example: templateEditor.setBackgroundColor(backgroundColor); // Or setBackgroundImage
                break;
            case "halverson-default":
                primaryColor = "#D12026"; // Red
                secondaryColor = "#FFFFFF"; // White
                accentColor = "#000000"; // Black
                backgroundColor = "#000000";
                textColor = "#FFFFFF";
                break;
            // Add more schemes as needed
        }
        // Placeholder: Update a few common elements if they exist
        templateEditor.canvas.getObjects().forEach(obj => {
            if (obj.isTextType) {
                if (obj.id && obj.id.toLowerCase().includes("headline")) {
                    obj.set("fill", primaryColor);
                } else if (obj.id && obj.id.toLowerCase().includes("date")) {
                    obj.set("fill", secondaryColor);
                } else if (obj.id && obj.id.toLowerCase().includes("division")) {
                    obj.set("fill", accentColor);
                } else {
                    obj.set("fill", textColor);
                }
            }
        });
        templateEditor.canvas.renderAll();
        templateEditor.saveState();
    }

    // --- Quick Layout Options ---
    const quickLayoutButtons = document.querySelectorAll("[data-quick-layout]");
    if (quickLayoutButtons) {
        quickLayoutButtons.forEach(button => {
            button.addEventListener("click", () => {
                const layoutName = button.dataset.quickLayout;
                applyQuickLayout(layoutName);
                quickLayoutButtons.forEach(btn => btn.classList.remove("bg-red-600", "text-white"));
                button.classList.add("bg-red-600", "text-white");
            });
        });
    }

    function applyQuickLayout(layoutName) {
        // This function would interact with templateEditor to rearrange or show/hide elements
        // Placeholder for now. Actual implementation depends on template structure and element IDs.
        console.log(`Applying quick layout: ${layoutName}`);
        // Example: templateEditor.applyLayoutPreset(layoutName);
    }

    // --- Mobile Preview Toggle (Placeholder) ---
    const mobilePreviewToggle = document.getElementById("mobile-preview-toggle");
    if (mobilePreviewToggle) {
        mobilePreviewToggle.addEventListener("click", () => {
            // Toggle a class on the canvas wrapper or body to simulate mobile view
            const canvasWrapper = document.querySelector(".canvas-wrapper"); // Assuming this exists
            if (canvasWrapper) {
                canvasWrapper.classList.toggle("mobile-view-simulation"); // Add CSS for this class
                console.log("Mobile preview toggled");
            }
        });
    }
    
    // Expose functions if needed by other scripts, e.g., template-editor.js
    window.uiEnhancer = {
        applyColorScheme,
        applyQuickLayout
    };
});

